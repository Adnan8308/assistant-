package com.example.assistant

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

object EventType {
    const val CLASS = "CLASS"
    const val EXAM = "EXAM"
    const val TUITION = "TUITION"
    const val OTHER = "OTHER"
    val all = listOf(CLASS, EXAM, TUITION, OTHER)
}

@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: String = EventType.OTHER,
    val startMillis: Long,
    val endMillis: Long? = null,
    val starred: Boolean = false,
    val notes: String = ""
)

@Dao
interface EventDao {
    @Query("SELECT * FROM events WHERE startMillis BETWEEN :from AND :to ORDER BY startMillis")
    fun between(from: Long, to: Long): Flow<List<Event>>

    @Query("SELECT * FROM events WHERE startMillis BETWEEN :from AND :to ORDER BY startMillis")
    suspend fun betweenOnce(from: Long, to: Long): List<Event>

    @Insert
    suspend fun insert(event: Event): Long

    @Update
    suspend fun update(event: Event)

    @Delete
    suspend fun delete(event: Event)
}

@Database(entities = [Event::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun events(): EventDao

    companion object {
        @Volatile private var instance: AppDb? = null

        fun get(context: Context): AppDb =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext, AppDb::class.java, "assistant.db"
                ).build().also { instance = it }
            }
    }
}
