package com.example.assistant

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Manages .gguf model files the owner picked. Files are copied into app-private storage. */
object LocalModels {

    fun dir(ctx: Context): File =
        File(ctx.applicationContext.filesDir, "models").also { it.mkdirs() }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.isFile && f.name.endsWith(".gguf", ignoreCase = true) }
            ?.sortedBy { it.name.lowercase() } ?: emptyList()

    fun fileFor(ctx: Context, name: String): File? =
        if (name.isBlank()) null else File(dir(ctx), name).takeIf { it.isFile }

    fun sizeText(f: File): String {
        val mb = f.length() / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format("%.1f GB", mb / 1024) else String.format("%.0f MB", mb)
    }

    /** Copies the picked file into the models folder. Returns the saved file name. */
    suspend fun import(ctx: Context, uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val app = ctx.applicationContext
            var name = "model.gguf"
            app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
            }
            name = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            require(name.endsWith(".gguf", ignoreCase = true)) { "Please pick a .gguf file" }
            val out = File(dir(app), name)
            val tmp = File(dir(app), "$name.part")
            app.contentResolver.openInputStream(uri)!!.use { input ->
                tmp.outputStream().use { input.copyTo(it, 1 shl 16) }
            }
            if (out.exists()) out.delete()
            check(tmp.renameTo(out)) { "Could not save the model file" }
            name
        }
    }

    fun delete(ctx: Context, name: String) {
        fileFor(ctx, name)?.delete()
    }
}

/**
 * Local text generation. The model files and the picker work now; the native llama.cpp
 * engine is NOT installed yet (roadmap M14). Until then ask() returns a clear message.
 * To plug the engine in: set `available` to true and implement ask().
 */
object LocalLlm {
    const val available = false

    suspend fun ask(
        ctx: Context,
        modelName: String,
        system: String,
        history: List<Pair<String, String>>,
        user: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val f = LocalModels.fileFor(ctx, modelName) ?: error("Local model file not found. Pick one in Settings.")
            error("The local model engine is not installed yet (milestone M14). Model file is ready: ${f.name}")
        }
    }
}
