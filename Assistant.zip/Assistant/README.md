# My Assistant (working name)

Personal Android schedule assistant: calendar home screen, exam warnings,
background reminders, and (later) local AI + folder access + Claude/ChatGPT API.

## Run it
1. Install Android Studio (free).
2. File > Open > select this folder. Let Gradle sync (needs internet once).
3. Plug in a phone (USB debugging on) or create an emulator, press Run.

## Continue development with Claude (free plan)
Read `HANDOFF.md`. Short version: open a new chat, paste the prompt from
`HANDOFF.md`, attach the files it lists, ask for ONE roadmap item.
At the end, update `SESSION_LOG.md` and `ROADMAP.md`.

## Files
- `PROJECT_BRIEF.md`  vision, architecture, decisions (the "why")
- `ROADMAP.md`        small tasks, checked off as done
- `SESSION_LOG.md`    what each session did, known problems
- `HANDOFF.md`        the prompt to paste into a new chat
- `app/`              the Android project
