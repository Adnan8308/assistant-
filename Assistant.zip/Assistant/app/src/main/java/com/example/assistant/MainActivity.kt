package com.example.assistant

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannel(this)
        Scheduler.schedule(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val dao = AppDb.get(this).events()
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(dao)
                }
            }
        }
    }
}

private val zone: ZoneId get() = ZoneId.systemDefault()
private fun startOfDay(d: LocalDate) = d.atStartOfDay(zone).toInstant().toEpochMilli()

@Composable
fun HomeScreen(dao: EventDao) {
    val scope = rememberCoroutineScope()
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var showAdd by remember { mutableStateOf(false) }

    val monthEvents by remember(month) {
        dao.between(startOfDay(month.atDay(1)), startOfDay(month.plusMonths(1).atDay(1)) - 1)
    }.collectAsState(initial = emptyList())

    val now = remember { System.currentTimeMillis() }
    val weekEvents by remember {
        dao.between(now, now + Engine.EXAM_WARNING_DAYS * 24 * 3600_000)
    }.collectAsState(initial = emptyList())

    val byDate = Engine.groupByDate(monthEvents)
    val warnings = Engine.examWarnings(weekEvents, now)

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            // Exam warning banner
            warnings.forEach {
                Surface(
                    color = Color(0xFFFFF3E0),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Text(Engine.warningText(it), Modifier.padding(12.dp))
                }
            }

            // Month header
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { month = month.minusMonths(1) }) {
                    Icon(Icons.Filled.ChevronLeft, "Previous month")
                }
                Text(
                    "${month.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${month.year}",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { month = month.plusMonths(1) }) {
                    Icon(Icons.Filled.ChevronRight, "Next month")
                }
            }

            // Weekday labels (Sunday first)
            Row(Modifier.fillMaxWidth()) {
                listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                    Text(it, Modifier.weight(1f), style = MaterialTheme.typography.labelMedium,
                        color = Color.Gray, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }

            // Day grid
            val lead = month.atDay(1).dayOfWeek.let { if (it == DayOfWeek.SUNDAY) 0 else it.value }
            val cells: List<LocalDate?> =
                List(lead) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth()) {
                    for (i in 0 until 7) {
                        val date = week.getOrNull(i)
                        Box(Modifier.weight(1f).aspectRatio(1f), contentAlignment = Alignment.Center) {
                            if (date != null) {
                                DayCell(
                                    date = date,
                                    isSelected = date == selected,
                                    isToday = date == LocalDate.now(),
                                    events = byDate[date].orEmpty(),
                                    onClick = { selected = date }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(
                selected.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(4.dp))

            val dayEvents = byDate[selected].orEmpty()
            if (dayEvents.isEmpty()) {
                Text("Nothing scheduled.", color = Color.Gray)
            }
            LazyColumn(Modifier.weight(1f)) {
                items(dayEvents, key = { it.id }) { e ->
                    EventRow(
                        event = e,
                        onStar = { scope.launch { dao.update(e.copy(starred = !e.starred)) } },
                        onDelete = { scope.launch { dao.delete(e) } }
                    )
                }
            }
        }

        FloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp)
        ) { Icon(Icons.Filled.Add, "Add event") }
    }

    if (showAdd) {
        AddEventDialog(
            date = selected,
            onDismiss = { showAdd = false },
            onSave = { e -> scope.launch { dao.insert(e) }; showAdd = false }
        )
    }
}

@Composable
fun DayCell(date: LocalDate, isSelected: Boolean, isToday: Boolean, events: List<Event>, onClick: () -> Unit) {
    val bg = when {
        isSelected -> MaterialTheme.colorScheme.primaryContainer
        isToday -> Color(0xFFEEEEEE)
        else -> Color.Transparent
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clip(CircleShape).background(bg).clickable(onClick = onClick).padding(6.dp)
    ) {
        Text(date.dayOfMonth.toString(), fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal)
        Box(Modifier.height(8.dp), contentAlignment = Alignment.Center) {
            if (events.isNotEmpty()) {
                val color = when {
                    events.any { it.type == EventType.EXAM } -> Color(0xFFD32F2F)
                    events.any { it.starred } -> Color(0xFFF9A825)
                    else -> MaterialTheme.colorScheme.primary
                }
                Box(Modifier.size(6.dp).clip(CircleShape).background(color))
            }
        }
    }
}

@Composable
fun EventRow(event: Event, onStar: () -> Unit, onDelete: () -> Unit) {
    val time = Instant.ofEpochMilli(event.startMillis).atZone(zone).toLocalTime()
        .format(DateTimeFormatter.ofPattern("HH:mm"))
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(event.title, style = MaterialTheme.typography.bodyLarge)
            Text("$time  ·  ${event.type.lowercase()}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        IconButton(onClick = onStar) {
            if (event.starred) Icon(Icons.Filled.Star, "Unstar", tint = Color(0xFFF9A825))
            else Icon(Icons.Outlined.StarBorder, "Star")
        }
        IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete") }
    }
}

@Composable
fun AddEventDialog(date: LocalDate, onDismiss: () -> Unit, onSave: (Event) -> Unit) {
    var title by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(EventType.CLASS) }
    var time by remember { mutableStateOf("09:00") }
    var starred by remember { mutableStateOf(false) }
    val parsedTime = runCatching { LocalTime.parse(time) }.getOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to ${date.format(DateTimeFormatter.ofPattern("d MMM"))}") },
        text = {
            Column {
                OutlinedTextField(title, { title = it }, label = { Text("Title (e.g. Anatomy)") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    EventType.all.take(3).forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.lowercase()) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    time, { time = it }, label = { Text("Time (HH:mm)") }, singleLine = true,
                    isError = parsedTime == null
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(starred, { starred = it })
                    Text("Important (star)")
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() && parsedTime != null,
                onClick = {
                    val start = date.atTime(parsedTime!!).atZone(zone).toInstant().toEpochMilli()
                    onSave(Event(title = title.trim(), type = type, startMillis = start, starred = starred))
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
