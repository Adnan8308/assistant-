# Project Brief

## Owner context
Medical student (MBBS, Bangladesh). Needs: class/exam/tuition schedule, exam
warnings, reminders, quick access to study files. Free Claude plan, so work is
done in small sessions. Keep every change small and testable.

## Vision
A personal assistant app. Some things run automatically in the background,
some happen on command (text or voice), and AI helps only where rules cannot.

## Core architecture rule
Two layers. Never mix them.

1. ENGINE (plain Kotlin, no AI): calendar, database, reminders, exam rules,
   "next 7 hours", notifications. Deterministic and testable. Must work with
   zero AI and zero internet.
2. AI LAYER (optional, replaceable): turns natural language into structured
   actions the engine already supports, e.g.
   "Anatomy exam Sunday 9am, star it" ->
   {"action":"add_event","title":"Anatomy","type":"EXAM","start":"2026-11-29T09:00","starred":true}
   The AI never touches the database directly; it returns JSON, the app
   validates it, the engine executes it.

## Platform
Android only (Kotlin, Jetpack Compose, Room, WorkManager). iOS blocks
background work, opening other apps and folder access, so it is not a target.

## Decisions so far
- Package: com.example.assistant (rename before publishing)
- Storage: Room (local SQLite). Sync with the phone calendar comes later via
  CalendarContract.
- Background: WorkManager periodic job (15 min minimum on Android).
- Event types: CLASS, EXAM, TUITION, OTHER.
- Exam warning: any EXAM within 7 days, shown as a soft banner + notification.
- Local AI (later): small 1-3B model (Gemma/Qwen/Phi) via MediaPipe LLM or
  llama.cpp, woken only on command to save battery. Used for JSON extraction.
- Cloud AI (later): optional Claude / OpenAI API with a user-pasted key,
  stored in encrypted storage. Used for heavy tasks (revision plans).
- Folders (later): Android Storage Access Framework (user picks a folder,
  app keeps the permission). Index file names, tag by subject.
- Open apps (later): Android Intents (camera, calendar, Claude app, etc).

## Non-goals for now
iOS, accounts/login, cloud sync, always-running AI.
