# Roadmap

Rule: one item per session. Each item should fit in one free-plan session.
Mark [x] when it builds AND works on a device. Add new items at the bottom.

## Phase 1: Engine (no AI)
- [x] M0  Project base: Room db, month calendar with dots, day list, add/delete, exam banner, background notification worker (written, NOT yet tested on a device)
- [ ] M1  Build and run on a phone; fix any compile errors (first thing to do)
- [ ] M2  Edit event screen (change title/time/type), star toggle on list
- [ ] M3  Per-event reminders (alarm X minutes before) with AlarmManager exact alarms
- [ ] M4  Recurring events (weekly class timetable)
- [ ] M5  Persistent "Today / next 7 hours" notification, starred first
- [ ] M6  Two-way sync with phone calendar (CalendarContract)
- [ ] M7  Settings screen (exam warning days, quiet hours)

## Phase 2: Commands and files
- [ ] M8  Text command box with a simple rule parser ("exam anatomy sunday 9am")
- [ ] M9  Folder permission (SAF) + file list + search by name
- [ ] M10 Tag files by subject, "find my biochemistry slides"
- [ ] M11 Open-app commands via Intents (camera, calendar, Claude)

## Phase 3: AI layer
- [ ] M12 AI interface (`CommandInterpreter`) with JSON schema + validator, using fake/rule parser first
- [ ] M13 Cloud API backend (Claude or OpenAI, user key in encrypted storage)
- [ ] M14 Local model backend (MediaPipe LLM), offline commands
- [ ] M15 Study planner: exam in N days -> suggested study blocks from chosen files
- [ ] M16 Voice input

## Ideas parking lot
- Pomodoro/study timer linked to exam subjects
- Weekly summary notification
