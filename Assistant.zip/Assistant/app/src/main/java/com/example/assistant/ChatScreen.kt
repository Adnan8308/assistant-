package com.example.assistant

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.time.LocalDateTime

data class ChatMsg(val fromUser: Boolean, val text: String)

@Composable
fun ChatScreen(
    dao: EventDao,
    chatDao: ChatDao,
    settings: AiSettings,
    msgs: SnapshotStateList<ChatMsg>,
    history: MutableList<Pair<String, String>>
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1)
    }

    /** Saves in order, in one coroutine, so ids stay in the same order as on screen. */
    fun saveAll(vararg items: ChatEntity) {
        scope.launch { items.forEach { chatDao.insert(it) } }
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        input = ""
        msgs.add(ChatMsg(true, text))

        val provider = settings.provider
        val key = settings.keyFor(provider)
        val problem: String? = when {
            provider == Provider.OFF ->
                "No AI selected yet. Open Settings, choose an AI, and add your API key or local model."
            provider == Provider.LOCAL && settings.localModel.isBlank() ->
                "No local model selected. Open Settings and pick a .gguf file."
            provider.needsKey && key.isBlank() -> "No API key saved for ${provider.label}. Add it in Settings."
            else -> null
        }
        if (problem != null) {
            msgs.add(ChatMsg(false, problem))
            saveAll(ChatEntity(fromUser = true, text = text), ChatEntity(fromUser = false, text = problem))
            return
        }

        busy = true
        scope.launch {
            val system = CommandInterpreter.systemPrompt(LocalDateTime.now())
            val result = if (provider == Provider.LOCAL) {
                LocalLlm.ask(ctx, settings.localModel, system, history.takeLast(10), text)
            } else {
                AiClient.ask(provider, key, settings.modelFor(provider), system, history.takeLast(10), text)
            }
            result.onSuccess { reply ->
                val shown: String = when (val i = CommandInterpreter.interpret(reply)) {
                    is Interpreted.AddEvent -> {
                        dao.insert(i.event)
                        "Added: ${CommandInterpreter.describe(i.event)}"
                    }
                    is Interpreted.Text -> i.text
                }
                history.add("user" to text)
                history.add("assistant" to reply)
                msgs.add(ChatMsg(false, shown))
                chatDao.insert(ChatEntity(fromUser = true, text = text, contextText = text))
                chatDao.insert(ChatEntity(fromUser = false, text = shown, contextText = reply))
            }.onFailure {
                val err = "Error: ${it.message}"
                msgs.add(ChatMsg(false, err))
                chatDao.insert(ChatEntity(fromUser = true, text = text))
                chatDao.insert(ChatEntity(fromUser = false, text = err))
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "AI: ${settings.provider.label}",
                style = MaterialTheme.typography.labelMedium,
                color = Color.Gray
            )
            TextButton(
                enabled = msgs.isNotEmpty() && !busy,
                onClick = {
                    msgs.clear()
                    history.clear()
                    scope.launch { chatDao.clear() }
                }
            ) { Text("Clear chat") }
        }
        Spacer(Modifier.height(4.dp))

        if (msgs.isEmpty()) {
            Text(
                "Try: \"Anatomy exam next Sunday 9am, star it\" or ask a study question.",
                color = Color.Gray
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(msgs) { m ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(m.text, Modifier.padding(10.dp))
                    }
                }
            }
        }

        if (busy) Text("Thinking...", color = Color.Gray, modifier = Modifier.padding(4.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message") },
                maxLines = 4
            )
            IconButton(onClick = { send() }, enabled = !busy) {
                Icon(Icons.AutoMirrored.Filled.Send, "Send")
            }
        }
    }
}
