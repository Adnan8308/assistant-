package com.example.assistant

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

/** Bottom tabs: Calendar, Assistant (chat), Settings. */
@Composable
fun AppRoot(dao: EventDao) {
    val ctx = LocalContext.current
    val settings = remember { AiSettings(ctx) }
    val chatDao = remember { AppDb.get(ctx).chat() }
    var tab by remember { mutableIntStateOf(0) }

    // Chat state lives here so it survives switching tabs; it is also saved in the database.
    val msgs = remember { mutableStateListOf<ChatMsg>() }
    val history = remember { mutableListOf<Pair<String, String>>() }

    // Load saved chat once when the app opens.
    LaunchedEffect(Unit) {
        if (msgs.isEmpty()) {
            chatDao.recent(200).forEach { m ->
                msgs.add(ChatMsg(m.fromUser, m.text))
                m.contextText?.let { c ->
                    history.add((if (m.fromUser) "user" else "assistant") to c)
                }
            }
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.CalendarMonth, null) },
                    label = { Text("Calendar") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.ChatBubble, null) },
                    label = { Text("Assistant") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Settings, null) },
                    label = { Text("Settings") }
                )
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(dao)
                1 -> ChatScreen(dao, chatDao, settings, msgs, history)
                else -> SettingsScreen(settings)
            }
        }
    }
}
