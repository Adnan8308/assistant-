# START HERE (briefing for Claude)

Read this whole file before doing anything. It is the project's memory. Chats forget;
this file and the other project files do not. Update them at the end of every session.

## The owner and the constraints
- Medical student in Bangladesh (timezone Asia/Dhaka). Free Claude plan, so limits reset
  and sessions are short. Keep answers short and simple: the owner reads on a phone.
- NO laptop or PC. Everything is done from a phone: GitHub in a mobile browser, Files app,
  installing APKs. Never tell the owner to "run gradle" or "open Android Studio".
- Claude cannot compile Android code in chat. Builds happen in GitHub Actions; the owner
  pastes the red error text back. So: double-check imports, nullability, library versions.

## What the owner wants (the vision)
A personal Android assistant app. Home screen = month calendar with dots on busy days;
tap a day to see classes (Anatomy, Physiology, Biochemistry), exams, tuition. Exam within
7 days = soft warning naming the subject + study suggestion. Background notifications for
the next 7 hours, starred items first. Reminders set by command. Schedule <-> calendar
two-way. Access to folders the owner permits, picking study files. Open other apps on
command (camera, calendar, Claude). Local AI models later; optional Claude/ChatGPT API.
Chat history must be saved.

## Architecture rule (never break)
1. ENGINE = plain Kotlin, no AI, works offline: database, calendar, reminders, exam rules.
2. AI LAYER = optional. The AI returns text or a JSON action (e.g. add_event). The app
   validates the JSON (CommandInterpreter) and the engine executes it. The AI never
   touches the database directly.
Stack: Kotlin, Jetpack Compose (Material3), Room, WorkManager. Android only.
Package: com.example.assistant. Pinned versions: AGP 8.5.2, Kotlin 2.0.20,
KSP 2.0.20-1.0.25, Compose BOM 2024.09.00, Room 2.6.1, WorkManager 2.9.1, compileSdk 34,
minSdk 26. Build uses Gradle 8.9 (set in the workflow; there is no gradle wrapper).

## Build and delivery pipeline (important)
- The owner has a private GitHub repo with two things: `Assistant.zip` (the whole project)
  and `.github/workflows/build.yml` (copy kept in `docs/build.yml`).
- On every push, GitHub Actions unzips Assistant.zip, builds the debug APK and uploads two
  artifacts: `app-debug-apk` (install on phone) and `project-snapshot` (this file + docs +
  all code in one text file; the owner attaches it to a new chat).
- Source of truth = Assistant.zip. To change the app: produce a complete, updated
  Assistant.zip (build the folder with file tools, zip it) and tell the owner to upload it
  to the repo with Add file > Upload files (same name replaces the old one).
  If file tools are unavailable, say so and give complete changed files; ask the owner how
  they want to apply them. Never give code fragments.
- If the build fails: owner copies the red lines from Actions > failed run > Build step.

## File map (app/src/main/java/com/example/assistant/)
- Event.kt        Event entity, EventDao, AppDb (Room, version 2, MIGRATION_1_2)
- ChatStore.kt    ChatEntity + ChatDao (saved chat history)
- Engine.kt       pure functions: exam warnings, next-7-hours, group by date, texts
- Notifier.kt     notification channel/post, Scheduler (15-min WorkManager), NotifyWorker
- MainActivity.kt activity + HomeScreen (calendar grid, day list, add dialog, exam banner)
- Root.kt         AppRoot: bottom tabs Calendar / Assistant / Settings, loads saved chat
- LocalModels.kt  LocalModels (gguf files in app storage) + LocalLlm (engine stub, M14)
- ChatScreen.kt   chat UI, sends to AI, saves messages, Clear chat
- SettingsScreen.kt AI provider/key/model, notification permission + test button
- AiClient.kt     Provider, AiSettings (SharedPreferences), AiClient (Claude/OpenAI/Gemini HTTP),
                  CommandInterpreter (system prompt, JSON -> Event)
Other: AndroidManifest.xml (POST_NOTIFICATIONS, INTERNET), gradle files, ROADMAP.md,
SESSION_LOG.md, PROJECT_BRIEF.md, HANDOFF.md (owner's instructions), docs/build.yml.

## Current state (update this section each session)
- Builds and installs on the owner's phone (M1 done). Chat/AI/settings/history written
  but NOT yet verified on the phone. See ROADMAP.md (M1b) for what to check.
- Session 5: Gemini provider + local .gguf model picker written, NOT yet tested. LocalLlm is a stub until M14.
- Known gaps: API key stored in plain app-private SharedPreferences (TODO encrypt);
  local model is a disabled placeholder; no edit-event screen; no per-event reminders.
- Database rule: if an entity changes, bump the Room version AND write a Migration,
  otherwise the owner's saved events are lost or the app crashes.

## How to work each session
1. Read START_HERE.md, ROADMAP.md, SESSION_LOG.md (and the code that the task touches).
2. Do ONE roadmap item (the one the owner names, else the first unchecked in order).
3. Deliver: updated Assistant.zip with the changed files, plus updated ROADMAP.md,
   SESSION_LOG.md (append a new entry, never delete old ones) and this file's
   "Current state". Only tick a roadmap box if the owner confirmed it works on the phone;
   otherwise mark it "written, NOT yet tested".
4. Tell the owner the exact next steps in 4-6 short lines (upload zip, wait for tick,
   download APK, install, what to test).
5. Keep the reply short. Do not re-explain the whole project to the owner.

## Prompt the owner pastes into a new chat
"Read the attached project snapshot (or START_HERE.md). Continue my Android assistant app.
Today's task: <what I want, or an error pasted from GitHub Actions>."
