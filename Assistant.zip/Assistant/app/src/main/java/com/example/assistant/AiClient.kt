package com.example.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Which AI backend the chat uses. LOCAL is a placeholder for a later milestone. */
enum class Provider(val label: String, val defaultModel: String) {
    OFF("Off (no AI)", ""),
    LOCAL("Local model (coming soon)", ""),
    CLAUDE("Claude (Anthropic)", "claude-haiku-5-5"),
    OPENAI("ChatGPT (OpenAI)", "gpt-4o-mini")
}

/** Stores provider, API keys and model names in app-private storage. TODO: encrypt keys. */
class AiSettings(context: Context) {
    private val p = context.applicationContext
        .getSharedPreferences("ai_settings", Context.MODE_PRIVATE)

    var provider: Provider
        get() = runCatching { Provider.valueOf(p.getString("provider", "OFF") ?: "OFF") }
            .getOrDefault(Provider.OFF)
        set(v) { p.edit().putString("provider", v.name).apply() }

    fun keyFor(pr: Provider): String = p.getString("key_${pr.name}", "") ?: ""
    fun setKey(pr: Provider, key: String) { p.edit().putString("key_${pr.name}", key).apply() }

    fun modelFor(pr: Provider): String =
        p.getString("model_${pr.name}", null)?.takeIf { it.isNotBlank() } ?: pr.defaultModel

    fun setModel(pr: Provider, model: String) { p.edit().putString("model_${pr.name}", model).apply() }
}

/** Network layer. Knows nothing about the calendar. */
object AiClient {

    suspend fun ask(
        provider: Provider,
        key: String,
        model: String,
        system: String,
        history: List<Pair<String, String>>,
        user: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            when (provider) {
                Provider.CLAUDE -> askClaude(key, model, system, history, user)
                Provider.OPENAI -> askOpenAi(key, model, system, history, user)
                else -> error("No AI provider selected")
            }
        }
    }

    private fun askClaude(
        key: String, model: String, system: String,
        history: List<Pair<String, String>>, user: String
    ): String {
        val msgs = JSONArray()
        history.forEach { (role, text) -> msgs.put(JSONObject().put("role", role).put("content", text)) }
        msgs.put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("system", system)
            .put("messages", msgs)
            .toString()
        val res = post(
            "https://api.anthropic.com/v1/messages",
            mapOf(
                "x-api-key" to key,
                "anthropic-version" to "2023-06-01",
                "content-type" to "application/json"
            ),
            body
        )
        return JSONObject(res).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun askOpenAi(
        key: String, model: String, system: String,
        history: List<Pair<String, String>>, user: String
    ): String {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        history.forEach { (role, text) -> msgs.put(JSONObject().put("role", role).put("content", text)) }
        msgs.put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject().put("model", model).put("messages", msgs).toString()
        val res = post(
            "https://api.openai.com/v1/chat/completions",
            mapOf(
                "Authorization" to "Bearer $key",
                "Content-Type" to "application/json"
            ),
            body
        )
        return JSONObject(res).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.doOutput = true
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(300)}")
        return text
    }
}

sealed class Interpreted {
    data class AddEvent(val event: Event) : Interpreted()
    data class Text(val text: String) : Interpreted()
}

/**
 * AI LAYER glue: the AI replies with plain text or a JSON action. We validate the JSON
 * here, then the engine/database does the real work. The AI never touches the database.
 */
object CommandInterpreter {

    fun systemPrompt(now: LocalDateTime): String {
        val today = now.format(DateTimeFormatter.ofPattern("EEEE, yyyy-MM-dd HH:mm"))
        return """
            You are the assistant inside a personal schedule app. Today is $today (${ZoneId.systemDefault()}).
            If the user wants to add something to their schedule (class, exam, tuition, other),
            reply with ONLY one JSON object and nothing else, in this exact shape:
            {"action":"add_event","title":"Anatomy","type":"EXAM","start":"2026-11-29T09:00","starred":true}
            type must be one of CLASS, EXAM, TUITION, OTHER. start is local time, format yyyy-MM-ddTHH:mm.
            Resolve words like "tomorrow" or "next Sunday" using today's date.
            For anything else, answer normally and briefly in plain text.
        """.trimIndent()
    }

    fun interpret(reply: String): Interpreted {
        val s = reply.indexOf('{')
        val e = reply.lastIndexOf('}')
        if (s >= 0 && e > s) {
            val event: Event? = runCatching {
                val o = JSONObject(reply.substring(s, e + 1))
                if (o.optString("action") != "add_event") return@runCatching null
                val title = o.getString("title").trim()
                val rawType = o.optString("type", EventType.OTHER).uppercase()
                val type = if (rawType in EventType.all) rawType else EventType.OTHER
                val start = LocalDateTime.parse(o.getString("start"))
                Event(
                    title = title,
                    type = type,
                    startMillis = start.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),
                    starred = o.optBoolean("starred", false)
                )
            }.getOrNull()
            if (event != null && event.title.isNotEmpty()) return Interpreted.AddEvent(event)
        }
        return Interpreted.Text(reply.trim())
    }

    fun describe(e: Event): String {
        val t = java.time.Instant.ofEpochMilli(e.startMillis).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("EEE d MMM, HH:mm"))
        val star = if (e.starred) " ★" else ""
        return "${e.title} (${e.type.lowercase()}) on $t$star"
    }
}
