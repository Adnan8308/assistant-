# My Assistant (working name)

Personal Android schedule assistant: calendar home screen, exam warnings, background
reminders, AI chat (Claude / ChatGPT with your own key), saved chat history.

## Files
- `START_HERE.md`    briefing for Claude (read first in every new chat)
- `HANDOFF.md`       your steps for continuing the project from a phone
- `PROJECT_BRIEF.md` vision, architecture, decisions
- `ROADMAP.md`       small tasks, checked off as done
- `SESSION_LOG.md`   what each session did, known problems
- `docs/build.yml`   copy of the GitHub Actions workflow (lives at .github/workflows/build.yml)
- `app/`             the Android project
