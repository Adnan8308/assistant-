package com.example.assistant

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * ENGINE: pure functions, no Android, no AI. Easy to unit test.
 * Anything "smart" in the app should end up calling these.
 */
object Engine {

    const val EXAM_WARNING_DAYS = 7L

    fun toDate(millis: Long, zone: ZoneId = ZoneId.systemDefault()): LocalDate =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()

    /** Exams happening from now until [days] days ahead. */
    fun examWarnings(events: List<Event>, nowMillis: Long, days: Long = EXAM_WARNING_DAYS): List<Event> {
        val limit = nowMillis + days * 24 * 3600_000
        return events.filter {
            it.type == EventType.EXAM && it.startMillis in nowMillis..limit
        }.sortedBy { it.startMillis }
    }

    /** Whole days from today to the event's date (0 = today). */
    fun daysUntil(event: Event, today: LocalDate = LocalDate.now()): Long =
        ChronoUnit.DAYS.between(today, toDate(event.startMillis))

    /** Events starting within the next [hours] hours, starred first, then by time. */
    fun upcoming(events: List<Event>, nowMillis: Long, hours: Long = 7): List<Event> {
        val limit = nowMillis + hours * 3600_000
        return events
            .filter { it.startMillis in nowMillis..limit }
            .sortedWith(compareByDescending<Event> { it.starred }.thenBy { it.startMillis })
    }

    /** Map of date -> events, used for the dots on the calendar. */
    fun groupByDate(events: List<Event>): Map<LocalDate, List<Event>> =
        events.groupBy { toDate(it.startMillis) }

    fun warningText(event: Event, today: LocalDate = LocalDate.now()): String {
        val d = daysUntil(event, today)
        val whenText = when (d) {
            0L -> "today"
            1L -> "tomorrow"
            else -> "in $d days"
        }
        return "${event.title} exam $whenText. Time to study."
    }
}
