# How to continue with any Claude (for you, the owner)

Claude forgets between chats. The project files are the memory. Everything a new Claude
needs is in `START_HERE.md`, and each GitHub build makes ONE file with everything.

## Start a new session (phone, 2 minutes)
1. Open GitHub > your repo > **Actions** > the latest green run > **Artifacts** >
   download `project-snapshot`. Extract it in your Files app. You get `project-snapshot.md`.
   (If the latest run is red, the snapshot is still made, so you can still download it.)
2. Open a NEW chat with Claude and attach `project-snapshot.md`.
3. Paste:
   "Read the attached project snapshot. Continue my Android assistant app.
   Today's task: <what you want, or paste the build error>"
4. Claude gives you an updated `Assistant.zip`. Upload it to the repo:
   **Add file > Upload files > Commit changes** (same name replaces the old one).
5. Wait for the green tick in **Actions**, download `app-debug-apk`, install it.

## Tips to save your free limit
- One small task per session. Test on the phone before the next one.
- For a build error, paste only the red lines.
- When the limit hits, stop and come back after the reset; nothing is lost.

## If something breaks
- Red cross in Actions: copy the red error lines into a new chat (with the snapshot).
- App crashes on open: say what you saw and which version you installed.
- Keep your last working APK file so you can go back.

## Back-up
The GitHub repo is your backup. `Assistant.zip` there is always the full project.
