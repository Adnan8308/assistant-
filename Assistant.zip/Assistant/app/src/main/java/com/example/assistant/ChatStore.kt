package com.example.assistant

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query

/**
 * One saved chat line.
 * [text] is what the user sees. [contextText] is what gets sent back to the AI as history
 * (null = a local message such as an error, never sent to the AI).
 */
@Entity(tableName = "chat_messages")
data class ChatEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromUser: Boolean,
    val text: String,
    val contextText: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ChatDao {
    /** The latest [limit] messages, oldest first. */
    @Query("SELECT * FROM (SELECT * FROM chat_messages ORDER BY id DESC LIMIT :limit) ORDER BY id")
    suspend fun recent(limit: Int): List<ChatEntity>

    @Insert
    suspend fun insert(message: ChatEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clear()
}
