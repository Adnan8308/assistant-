package com.example.assistant

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(settings: AiSettings) {
    val ctx = LocalContext.current

    var provider by remember { mutableStateOf(settings.provider) }
    var key by remember(provider) { mutableStateOf(settings.keyFor(provider)) }
    var model by remember(provider) { mutableStateOf(settings.modelFor(provider)) }
    var saved by remember { mutableStateOf(false) }

    var notifOk by remember { mutableStateOf(Notifier.canPost(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { notifOk = it }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        // ---- AI ----
        Text("AI model", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Provider.values().forEach { p ->
            val enabled = p != Provider.LOCAL
            Row(
                Modifier.fillMaxWidth().clickable(enabled = enabled) {
                    provider = p
                    settings.provider = p
                    saved = false
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = provider == p,
                    enabled = enabled,
                    onClick = { provider = p; settings.provider = p; saved = false }
                )
                Text(p.label, color = if (enabled) Color.Unspecified else Color.Gray)
            }
        }

        if (provider == Provider.CLAUDE || provider == Provider.OPENAI) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; saved = false },
                label = { Text("API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; saved = false },
                label = { Text("Model name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                settings.setKey(provider, key.trim())
                settings.setModel(provider, model.trim())
                saved = true
            }) { Text("Save") }
            if (saved) Text("Saved.", color = Color(0xFF2E7D32))
            Spacer(Modifier.height(4.dp))
            Text(
                "Your key stays on this phone and is sent only to the provider you chose. " +
                    "API usage is billed by the provider, separate from any chat subscription.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        Spacer(Modifier.height(24.dp))

        // ---- Notifications ----
        Text("Notifications", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(if (notifOk) "Allowed." else "Not allowed yet.")
        Spacer(Modifier.height(8.dp))
        if (!notifOk && Build.VERSION.SDK_INT >= 33) {
            Button(onClick = { permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                Text("Allow notifications")
            }
            Spacer(Modifier.height(8.dp))
        }
        OutlinedButton(onClick = {
            Notifier.ensureChannel(ctx)
            Notifier.show(ctx, "Test", "Notifications are working.")
        }) { Text("Send test notification") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = {
            val i = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            ctx.startActivity(i)
        }) { Text("Open phone notification settings") }
        Spacer(Modifier.height(4.dp))
        Text(
            "On Android 12 or older, notifications are allowed automatically and no prompt appears.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )
    }
}
