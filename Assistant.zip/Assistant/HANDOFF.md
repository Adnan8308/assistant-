# HANDOFF: how to continue with Claude on the free plan

Claude forgets between chats. These files are the memory. Treat them as the
source of truth, not the chat.

## Start of every new session (2 minutes)
1. Open a NEW chat.
2. Attach: `PROJECT_BRIEF.md`, `ROADMAP.md`, `SESSION_LOG.md`, plus ONLY the
   code files that the task touches (not the whole project; saves your limit).
3. Paste this prompt, filling the last line:

---
You are continuing development of my Android assistant app. I attached the
brief, roadmap, session log and relevant code. Read them first.
Rules:
- Keep the ENGINE (plain Kotlin) separate from the AI layer, as in the brief.
- Do ONE roadmap item only, the one I name below. Do not refactor unrelated code.
- Give complete changed files (not fragments) so I can replace them directly.
- You cannot compile here, so double-check imports, nullability and versions.
- At the end give me: (a) a new SESSION_LOG.md entry, (b) the updated
  ROADMAP.md checkboxes, (c) any new decision for PROJECT_BRIEF.md.
Today's task: <e.g. "M1: here is my build error: ...">
---

## During the session
- If Android Studio shows an error, copy the full error text and paste it.
  That is cheaper than describing it.
- Test on the phone before ending. Only tick a roadmap box if it works.

## End of every session (2 minutes)
1. Replace the changed files in your project.
2. Append the new entry to `SESSION_LOG.md`, update `ROADMAP.md`.
3. Optional: put the folder in a free GitHub repo so you have backups and
   history (Android Studio: VCS > Create Git Repository). 

## Saving your limit
- Short sessions on one item beat long ones.
- Don't re-upload the whole project; attach only the files involved.
- When the limit hits, stop. Come back after reset and start from step 1.
- For simple compile errors, ask for a small fix, not a rewrite.
