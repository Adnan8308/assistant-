package com.example.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

object Notifier {
    const val CHANNEL = "schedule"
    const val NOTIF_ID = 1

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Schedule", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun show(context: Context, title: String, text: String) {
        if (!canPost(context)) return
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOnlyAlertOnce(true)
            .build()
        NotificationManagerCompat.from(context).notify(NOTIF_ID, n)
    }
}

object Scheduler {
    /** Android's minimum for periodic background work is 15 minutes. */
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<NotifyWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "schedule_notify", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}

/** Runs in the background, even when the app is closed. */
class NotifyWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val dao = AppDb.get(applicationContext).events()
        val now = System.currentTimeMillis()

        val week = dao.betweenOnce(now, now + Engine.EXAM_WARNING_DAYS * 24 * 3600_000)
        val exams = Engine.examWarnings(week, now)
        val next = Engine.upcoming(week, now, hours = 7)

        if (exams.isEmpty() && next.isEmpty()) return Result.success()

        val fmt = DateTimeFormatter.ofPattern("HH:mm")
        val lines = mutableListOf<String>()
        exams.forEach { lines += Engine.warningText(it) }
        next.forEach {
            val time = java.time.Instant.ofEpochMilli(it.startMillis)
                .atZone(java.time.ZoneId.systemDefault()).toLocalTime()
            val star = if (it.starred) "★ " else ""
            lines += "$star${time.format(fmt)}  ${it.title} (${it.type.lowercase()})"
        }

        Notifier.show(applicationContext, "Coming up", lines.joinToString("\n"))
        return Result.success()
    }
}
