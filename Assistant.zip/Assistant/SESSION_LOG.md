# Session Log (newest at the bottom, never delete old entries)

## Session 1 - 2026-11-25
Done: wrote project base (M0). Gradle (Kotlin DSL), Manifest, Room entity/dao/db,
Engine.kt (pure functions), Notifier.kt + NotifyWorker.kt (15 min periodic),
MainActivity.kt (Compose month grid, dots, day list, add dialog, exam banner).
Not done: nothing was compiled or run (no Android SDK in the chat sandbox).
Known risks: library versions may need bumping in Android Studio; first sync
may show errors to paste back into Claude.
Next: M1 (build, run, fix errors).

## Session 2 - 2026-11-25
Done: M1 reached by user via GitHub Actions (no laptop): app built, installed, opens.
User noticed missing chat/AI/permission UI, so added M0b: Root.kt (3 tabs),
ChatScreen.kt, SettingsScreen.kt, AiClient.kt (Claude + OpenAI over HttpURLConnection,
AiSettings, CommandInterpreter: AI returns JSON add_event, validated, then inserted).
Manifest: INTERNET permission, adjustResize. MainActivity now calls AppRoot(dao).
Not done: not compiled or run. API keys stored in plain app-private SharedPreferences (TODO encrypt).
Chat history is lost when the app closes. Local model option is a disabled placeholder.
Known risks: build errors possible in new files; default model names may need changing in Settings.
Next: M1b (verify on phone), then M2.

## Session 3 - 2026-11-25
Done: M0c chat history persistence. New ChatStore.kt (ChatEntity, ChatDao). Event.kt: AppDb
now version 2 with MIGRATION_1_2 (creates chat_messages, keeps events), added chat().
Root.kt loads last 200 messages and rebuilds AI history on start. ChatScreen.kt saves each
exchange and has a Clear chat button. contextText column = what is sent back to the AI
(null for local/error messages).
Not done: not compiled or run. If the app crashes on start after updating, the migration SQL
is the first suspect (must match the entity columns exactly).
Next: M1b (verify on phone), then M2.
