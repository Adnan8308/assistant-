# Session Log (newest at the bottom, never delete old entries)

## Session 1 - 2026-11-25
Done: wrote project base (M0). Gradle (Kotlin DSL), Manifest, Room entity/dao/db,
Engine.kt (pure functions), Notifier.kt + NotifyWorker.kt (15 min periodic),
MainActivity.kt (Compose month grid, dots, day list, add dialog, exam banner).
Not done: nothing was compiled or run (no Android SDK in the chat sandbox).
Known risks: library versions may need bumping in Android Studio; first sync
may show errors to paste back into Claude.
Next: M1 (build, run, fix errors).
